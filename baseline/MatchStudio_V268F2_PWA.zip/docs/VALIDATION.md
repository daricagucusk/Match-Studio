# Doğrulama raporu — V2.6.8-F.2

Tarih: 22 Ekim 2026. Ortam: Linux, Node.js 24.19.0, Playwright Chromium. Testler sentetik kulüp/oyuncularla çalıştırılır; gerçek sporcu bilgisi kullanılmaz.

## Otomatik kontroller

`npm run check`: derleme + 17 Node/IndexedDB testi + 13 Chromium tarayıcı senaryosu. Güncelleme protokolü masaüstünde bir kez çalıştırılır; telefon ve katlanabilir projelerinde aynı protokol senaryosunun tekrarları bilerek atlanır (2 skip).

| Alan | Doğrulanan davranış |
| --- | --- |
| Kaynak ve paket | 49 özgün modül geri kazanımı, 1 yeni uygulama modülü; sözdizimi ve modül bağımlılıkları derlemede denetlenir. İçerik tabanlı service worker sürümü kullanılır. |
| Kulüp ayrımı | Bekleyen bağlantı ve sıraya alınmış yazma kulüp değişirse iptal edilir; diğer kulüpte kayıt oluşmaz. |
| Veritabanı uyumu | Sürüm 1 veritabanı sürüm 2'ye mevcut oyuncular korunarak açılır. Mevcut v2 ve yedek v1/v2/v3 korunur. |
| Atomiklik | İptal edilen çoklu store işlemi kayıtları korur. Maç silme bağlantılı oturum, olay, kadro, saha ve afişi birlikte temizler. Bağlı grup silinmez. Eski aktarım boş hedef gerektirir. |
| Şifreli yedek | AES-GCM dışa/içe aktarma; görsel Blob baytları ve canlı geçmiş eşleşir. Yanlış parola, değiştirilmiş şifreli veri, bozuk/eksik JSON ve iptal mevcut verileri değiştirmez. |
| Kurtarma | Önceki durum geri alınır. Kurtarma depolaması başarısızsa içe aktarma mevcut oyuncuları korur. Dosya çözülürken kulüp değişirse içe aktarma iptal edilir. |
| Canlı maç | Başlatma, duraklatma, devam, devre geçişi ve bitirme; arka plan süresinin duvar saatinden hesabı; şüpheli cihaz saati ve gerekçeli düzeltme. |
| Eşzamanlı olaylar | Aynı işlem anahtarı mükerrer olay oluşturmaz; eski revizyon reddedilir. Gol, kart, oyuncu değişikliği, olay sırası ve dakika hesabı doğrulanır. |
| Kullanıcı akışı | Kulüp/grup, dört oyuncu, fotoğraf, 3v3 maç, kadro, saha, canlı maç, değişiklik, sayfa yenileme ve PNG indirme. İkinci sekme olay değişikliğini alır. Masaüstünde sürükleyerek saha oyuncusu değişimi kontrol edilir. |
| Telefon yerleşimi | 1440×1000, 360×780 ve 840×980; temel sayfalarda yatay taşma ve işlenmemiş JavaScript hatası yok. |
| Yedek dosyası seçimi | Gerçek dosya seçici düğmesiyle aynı şifreli dosya iki kez seçilip geri yüklenir; üç ekran boyutunda uygulanır. |
| Çevrimdışı | Hazır durumundan sonra ağ kesilerek yenileme, kayıtların açılışı ve cihaz test sayfasına erişim. |
| Güncelleme | Bozuk dağıtım reddedilir; eski dosyalar sunulmaya devam eder. Yeni sürüm kabulü bekler; diğer sekmenin işlem kilidi güncellemeyi engeller. Kabul sonrası iki sekme yenilenir ve kulüp verisi korunur. |

## Paket doğrulaması

`npm run package` sonrası ZIP içindeki SHA256SUMS.txt ve service worker manifestindeki dosya özetleri ayrıca kontrol edilir. PWA paketinde kaynak, test bağımlılıkları veya başlangıç arşivi bulunmaz. Aynı kaynaklarla tekrar derleme/paketleme aynı çıktıları üretmelidir.

## Gerçek cihazda kalan kabul

Gerçek Samsung Z Fold 7 donanımına erişim olmadığı için Android PWA kurulumu, ekran menteşesi/klavye davranışı, dokunma ergonomisi, paylaşım uygulamaları ve en az 90 dakikalık stres denemesi tamamlanmadı. [Cihaz kontrol listesi](DEVICE_CHECKLIST.md) bu kabul için hazırlanmıştır.

Bu rapor performans veya tam güvenlik sertifikası değildir; yukarıdaki senaryoların kapsamını kaydeder. Canlı internete dağıtım yapılmadı.
