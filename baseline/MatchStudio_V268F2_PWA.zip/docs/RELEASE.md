# V2.6.8-F.2 dağıtımı

Bu paket üretim adayıdır. Gerçek cihaz kabulü için DEVICE_CHECKLIST.md kullanın.

## Değişiklikler

- F.1 R1 paketindeki 49 modül kaynak dosyalarına çıkarıldı; 1 PWA güncelleme modülü eklendi. Derleme manifesti kaynaklar için açık sıralama tutar.
- Kulüp değişiminde bekleyen bağlantı/yazma işlemleri iptal edilir; eski bağlantılar kapatılır. Veritabanı sürümü 2 ve mevcut kayıt adları korunur.
- Geri yükleme ve kurtarma, aynı kulübün yazma işlemleriyle Web Locks üzerinden koordine edilir. Kurtarma kopyası kaydedilemezse mevcut kayıtlar silinmez.
- UI işlemleri sürerken kulüp/maç değişimi ve tekrarlanan giriş engellenir.
- Service worker her dosyayı derleme SHA-256 manifestiyle doğrular. Eksik dağıtım reddedilir. Etkin sürüm yalnızca kendi önbelleğinden çalışır.
- Yeni sürüm kullanıcı kabulünü bekler; açık sekmelerdeki işlemler tamamlanmadan etkinleştirilmez. Kabul tüm uygulama sekmelerini yeniden başlatır.

## Dağıtım ve geri dönüş

1. Cihaz dışına şifreli JSON yedeği alın; parolayı ayrıca saklayın.
2. PWA ZIP'ini **mevcut origin, port ve alt dizini koruyarak** yayınlayın. HTTPS gereklidir (localhost hariç).
3. Dosyaları tek dağıtım olarak yayınlayın. HTML/JS/CSS gövdelerini barındırıcıda otomatik dönüştürmeyin; service worker manifesti tam dosya baytlarını doğrular. HTTP sıkıştırması kullanılabilir.
4. `sw.js` için no-cache/no-store kullanın; HTML/JS/CSS dosyalarını yanlış MIME ile veya SPA fallback HTML'si olarak sunmayın. Yerel sunucu doğru başlıkları uygular.
5. Açık uygulamada güncelleme bildirimini bekleyin; formları kaydedip kabul edin. Eski F.1'den ilk geçişte çevrimiçi yeniden açılış gerekebilir.
6. Çevrimdışı açılış, kayıtlar, yedek ve afiş indirmeyi doğrulayın.

Geri dönüşte önceki tam paketi aynı adreste yeniden yayınlayın ve sekmeleri kapatıp açın. Tarayıcı/site verilerini temizlemeyin. F.2 veri şemasını değiştirmez. Yedek gerektiğinde aynı kulübe açık onayla geri yüklenir; geri yükleme mevcut kulüp kayıtlarını değiştirir.

Eski sürüm önbellekleri, açık sekmelerin dosyalarının kaybolmaması için otomatik silinmez; çok sayıda dağıtımda depolama büyüyebilir. Cihazda alan azsa güncelleme kurulamayabilir; önce dış yedek alın ve cihaz alanını kontrol edin. Site verilerini temizlemek kulüp verilerini de siler.

## Sınırlar

APK, sunucu, kullanıcı hesabı, bulut eşitlemesi veya telemetri eklenmedi. Eski F.1 sekmeleri yeni Web Locks protokolünü bilmez; ilk geçişten önce onları kapatın. Gerçek cihaz ergonomisi, Android dosya paylaşımı ve uzun süreli stres testi otomatik tarayıcı testleriyle doğrulanmış sayılmaz.
