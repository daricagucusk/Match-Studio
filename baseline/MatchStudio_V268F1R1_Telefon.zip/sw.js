/* Match Studio V2.6.8-F.1 — Offline shell only; never serve HTML for JavaScript/CSS. */
const CACHE='matchstudio-universal-v268f1r1-backup-reselect-qa';
const SHELL=['./','./index.html','./app.bundle.js','./broadcast.css','./premium-v267.css','./live-clock-v268b.css','./live-substitutions-v268c.css','./live-pitch-v268d.css','./live-events-v268e.css','./assets/ms-emblem-mark.png','./assets/match-studio-brand-preview.png','./manifest.webmanifest','./device-test.html','./icons/icon-192.png','./icons/icon-512.png'];
const shellUrls=new Set(SHELL.map(path=>new URL(path,self.registration.scope).href));
self.addEventListener('install',event=>{
 event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(SHELL)).then(()=>self.skipWaiting()));
});
self.addEventListener('activate',event=>{
 event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(name=>name.startsWith('matchstudio-universal-v2')&&name!==CACHE).map(name=>caches.delete(name)))).then(()=>self.clients.claim()));
});
self.addEventListener('fetch',event=>{
 const req=event.request;
 if(req.method!=='GET'||new URL(req.url).origin!==self.location.origin)return;
 const isShell=shellUrls.has(req.url);
 const isNavigation=req.mode==='navigate';
 if(!isShell&&!isNavigation)return;
 event.respondWith((async()=>{
  try{
   const response=await fetch(req);
   if(response.ok&&isShell){
    const copy=response.clone();
    event.waitUntil(caches.open(CACHE).then(cache=>cache.put(req,copy)).catch(()=>{}));
   }
   return response;
  }catch(error){
   const cached=await caches.match(req);
   if(cached)return cached;
   if(isNavigation){
    const fallback=await caches.match(new URL('./index.html',self.registration.scope).href);
    if(fallback)return fallback;
   }
   return Response.error();
  }
 })());
});
